<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Tiny MediaCMS plugin version details.
 *
 * @package    tiny_mediacms
 * @copyright  2026 MediaCMS <https://mediacms.io>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026101901; // 2026-10-19
$plugin->requires  = 2024100700; // Requires Moodle 4.5+
$plugin->component = 'tiny_mediacms';
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = 'v1.0.2';
$plugin->dependencies = ['filter_mediacms' => 2026051100]; // Requires filter plugin for shared settings

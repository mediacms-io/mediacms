﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","km",{title:"លក្ខណៈ Placeholder",toolbar:"បង្កើត Placeholder",name:"ឈ្មោះ Placeholder",invalidName:"Placeholder មិន​អាច​ទទេរ ហើយក៏​មិន​អាច​មាន​តួ​អក្សរ​ទាំង​នេះ​ទេ៖ [, ], <, >",pathName:"placeholder"});
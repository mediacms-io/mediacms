﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","sk",{title:"Vlastnosti placeholdera",toolbar:"Vytvoriť placeholder",name:"Názov placeholdera",invalidName:"Placeholder nemôže byť prázdny a nemôže obsahovať žiadny z nasledujúcich znakov: [,],<,>",pathName:"placeholder"});
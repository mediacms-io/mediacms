﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","fr-ca",{title:"Sélecteur de couleur",preview:"Aperçu",config:"Insérez cette ligne dans votre fichier config.js",predefined:"Ensemble de couleur prédéfinies"});